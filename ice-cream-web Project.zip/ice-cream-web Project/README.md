Yummy Scoops!
It is a simple but elegant html, css and little js based web app. 

About the web app:
    It consist of a landing page with full width wallpaper along with app name in the center of the screen.

    It has a fixed navigation bar at the top of the screen, which is slight transparent in styling.
    On click of each tab in navigation the screen smoothly scrolls to that section. 

    The about section describes the ice cream parlour motto and has a carousel of different ice cream images
    Below that is the flavour section that displays the images of different flavours and on hovering over the images you get to see the name of the flavour.
    After that is the contact section giving two options of either calling for orders or visiting their shop to the mentioned address.
    Last you have an upward arrow icon to directly scroll up to the top of the page.

    All the images used for this application is stored in ./images folder.

How to view the application? 
    For viewing this app simply view the index.html file in the browser.