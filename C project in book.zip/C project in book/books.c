#include<stdio.h>
#include<string.h>
typedef struct book
{
	int id;
	char name[100];
	char author[100];
	double price;
	int rating;
}book;
//void storeinfo(book*,int);
void displayinfo(book*,int);
void hard_store(book*,int);
int search_book_by_id(book*,int,int);
int search_book_by_name(book*,int,char*);
int search_book_by_author(book*,int,char*);
void maximum_price(book*,int);
void maximum_rating(book*,int);
void update_by_price(book*,int);
void update_by_rating(book*,int);
void deleteinfo(book*,int);
void upload(book*,int);
void top_3_by_rating(book*,int);
void top_3_by_price(book*,int);
void swap(book* a,book* b);
void main()
 {                                            
	 book arr[5]; 	
	  int size=5;
	 //storeinfo(arr,5);
   	hard_store(arr,5);
   	int choice;
   	int press;
   	do{
	  printf("\n *****Select options for book***** \n");
	  printf(" press 1 to book details \n press 2 to search the book \n press 3 to max ratings and max price \n");
	  printf(" press 4 to top 3 books \n press 5 to delete \n press 6 to update \n press 7 to exit \n");
	  scanf("%d",&choice);
	  
	  switch(choice)
 {
	  	case 1:
	  		displayinfo(arr,5);
	  		break;
	  		case 2:
	  			printf("search by id press 1 \n search by name press 2 \n search by author press 3 \n");
            
                  
                  scanf("%d",&press);
                  if(press == 1)
                  {
     	            printf("enter the id \n");
     	            int id;
                  	scanf("%d",&id);
     	             search_book_by_id(arr,size,id);
	              }
                else if(press == 2)
             {
     	        printf("enter the name \n");
     	        char uname[50];
     	        scanf("%s",&uname);
               	search_book_by_name(arr,size,uname);    	
	          }
	 else if(press == 3)
	 {
	     printf("enter the author \n");
	     char uauthor;
	     scanf("%s",&uauthor);
	     search_book_by_author(arr,size,&uauthor);
     }
     else
     {
     	printf("invalid id,name or author");
	 }

	  		break;
	  		case 3:
	  			printf("If you want to dislplay maximum price,press 1 \n If you want display maximum rating, press 2. \n");
	  			scanf("%d",&press);
	  			if(press == 1)
	  			{
	  			maximum_price(arr,5);
				}
				else if (press == 2)
				{
					maximum_rating(arr,5);
				}
				else
				{
					printf("Invalid choice. \n");
				}
				break;
			case 4:	
			printf(" If you want to display top 3 book by price, press 1.\n If you want to display top 3 book by rating, press 2.\n");
                scanf("%d", &press);
                if (press == 1) {
                    top_3_by_price(arr, size);
                } else if (press == 2) {
                    top_3_by_rating(arr, size);
                } else {
                    printf(" Invalid choice.\n");
                }
                break;
            case 5:
            	deleteinfo(arr,size);
            	break;
            case 6: 
                
			    printf(" If you want to update price, press 1.\n If you want to update rating, press 2.\n");
                int p;
                scanf("%d",&p);
                if (p == 1) 
				{
                    update_by_price(arr,size);
                } 
				else if (p == 2) 
				{
                    update_by_rating(arr,size);
                } 
				else 
				{
                    printf(" Invalid choice.\n");
                }
	  			break;
	  		case 7:
	  			upload(arr,size);
	  			break;
	
	  		case 8:
	  			printf("Exiting...\n");
	  			break;
	  			default:
	  				printf("Invalid choice");
	  	}
	  }while(choice !=7);
}
// void storeinfo(book* arr,int size)
//{
//	printf("Enter the id: ");
//	scanf("%d",&arr[i].id);
//	
//	printf("Enter the name of book: ");
//	scanf("%s",&arr[i].name);
//	
//	printf("Enter the author:");
//	scanf("%s",&arr[i].author);
//	
//	printf("Enter the price : ");
//	sacnf("%lf",&arr[i].price);
//	
//	printf("Enter the rating");
//	scanf("%d",&arr[i].rating);	
//}	

 void hard_store(book* arr,int size)
{
	int i;
	for(i=0;i<size;i++)
	{
	
	    arr[0].id=2605;
		strcpy(arr[0].name,"guide");
		strcpy(arr[0].author,"narayan");
		arr[0].price=100;
		arr[0].rating=2;
		
		arr[1].id=2606;
		strcpy(arr[1].name,"maximum");
		strcpy(arr[1].author,"mehta");
		arr[1].price=200;
		arr[1].rating=3;
		
		arr[2].id=2607;
		strcpy(arr[2].name,"custody");
		strcpy(arr[2].author,"desai");
		arr[2].price=300;
		arr[2].rating=4;
		
		
		arr[3].id=2608;
		strcpy(arr[3].name,"chitra");
		strcpy(arr[3].author,"tagore");
		arr[3].price=500;
		arr[3].rating=5;
		
		
		arr[4].id=2609;
		strcpy(arr[4].name,"poems");
		strcpy(arr[4].author,"ramanujan");
		arr[4].price=600;
		arr[4].rating=5;	
	}
}
       void displayinfo(book* arr,int size)
   {
	int i;
	    printf("\n   -----------------------------------------------------------------------------------------------\n");
	    printf("    |     id        |      Name         |            author       |       price    |   rating   |");
		printf("\n   -----------------------------------------------------------------------------------------------\n");
	for(i=0;i<size;i++)
	{
		printf("    |      %d     |      %-6s      |          %-9s      |     %lf   |     %d      |",arr[i].id,arr[i].name,arr[i].author,arr[i].price,arr[i].rating);
		printf("\n   -----------------------------------------------------------------------------------------------\n");
           //	printf("id: %d \n name: %s \n author: %s \n price: %lf \n rating: %d\n",arr[i].id,arr[i].name,arr[i].author,arr[i].price,arr[i].rating);
        		
	}
}

int search_book_by_id(book* arr,int size,int no)
{
	
	int i,found=0;
	for(i=0;i<size;i++)
	{
		if(arr[i].id==no)
		{
			printf("book is found \n");
			printf("id: %d  \n name: %s \n author: %s \n price: %lf \n rating: %d \n",arr[i].id,arr[i].name,arr[i].author,arr[i].price,arr[i].rating);
			found = 1;
			return i;
			break;
		}
	}
	if(found==0)
	{
		printf("book is not found");
		return -1;
	}
}
int search_book_by_name(book* arr,int size,char* uname)
{
	int i,found=0;
		for(i=0;i<size;i++)
	{
		if(!strcmp(arr[i].name,uname))
		{
			printf("book is found \n");
			printf("id: %d  \n name: %s \n author: %s \n price: %lf \n rating %d \n",arr[i].id,arr[i].name,arr[i].author,arr[i].price,arr[i].rating);
			found = 1;
			break;
		}
	}
	if(found==0)
	{
		printf("book is not found");
		return -1;
	}
}
int search_book_by_author(book* arr,int size,char* uauthor)
{                                                           
	    int i,found=0;
		for(i=0;i<size;i++)
	{
		  if(!strcmp(arr[i].author,uauthor))
		{
			printf("book is found \n");
			printf("id: %d  \n name: %s \n author: %s \n price: %lf \n rating: %d",arr[i].id,arr[i].name,arr[i].author,arr[i].price,arr[i].rating);
			found = 1;
			break;
		}
	}
	       if(found==0)
	       {
		        printf("book is not found");
           }
}
void maximum_price(book* arr,int size)
{
	double max_price;
	int i;
	for(i=0;i<size;i++)
	{
		if(max_price < arr[i].price)
		{
			max_price = arr[i].price;
		}
	}
	printf("maximum price %lf \n",max_price);
}
void maximum_rating(book* arr,int size)
{
	int max_rating;
	int i,j;
	for(i=0;i<size;i++)
	{
		if(max_rating < arr[i].rating)
		{
			max_rating = arr[i].rating;	
			j=max_rating;		
		}
	}
	printf("maximum rating %d \n",j);
}
void update_by_price(book* arr,int size)
{
	printf("enter book id you want to update by price \n");
	int i,result;
	scanf("%d",&i);
	result=search_book_by_id(arr,size,i);
	if(result == -1)
	{
		printf("book not found");
	}
	else
	{
		printf("enter new price to update \n");
		double uprice;
		scanf("%lf",&uprice);
		arr[result].price=uprice;
		printf("price is updated successfully \n");
		//printf("id: %d \n name: %s \n author: %s \n price: %lf \n rating: %d\n",arr[result].id,arr[result].name,arr[result].author,arr[result].price,arr[result].rating);
        		displayinfo(arr,size);
	}
	}
void update_by_rating(book* arr,int size)
{
	printf("enter book id you want to update by rating \n");
	int i,result;
	scanf("%d",&i);
	result=search_book_by_id(arr,size,i);
	if(result == -1)
	{
		printf("book not found");
	}
	else
	{
		printf("enter new rating to update \n");
		int urating;
		scanf("%d",&urating);
		arr[result].rating=urating;
		printf("rating is updated successfully \n");
		//printf("id: %d \n name: %s \n author: %s \n price: %lf \n rating: %d\n",arr[result].id,arr[i].name,arr[result].author,arr[result].price,arr[result].rating);
        displayinfo(arr,size);
	}
}
void deleteinfo(book* arr,int size)
{
	printf("Enter the book id you want to delete \n");
	int num;
	scanf("%d",&num);
	int i,j,found = 0;
	for(i=0;i<size;i++)
	{
		if(arr[i].id == num)
		{
			found =1;
			for(j=i;j<size;j++)
			{
				arr[j]=arr[j+1];
			}
		}
	if(found == 1)
	{
	
		printf("book info was deleted.\n",arr[i].id);
		break;
    }
	}
	    printf("\n   -----------------------------------------------------------------------------------------------\n");
	    printf("    |     id       |      Name         |            author       |       price    |   rating   |");
		printf("\n   -----------------------------------------------------------------------------------------------\n");
	for(i=0;i<size-1;i++)
	{
	    printf("    |      %d     |     %s       |          %s      |     %lf   |     %d      |",arr[i].id,arr[i].name,arr[i].author,arr[i].price,arr[i].rating);
		printf("\n   -----------------------------------------------------------------------------------------------\n");
		//printf("%d %s %d %lf %d \n",arr[i].id,arr[i].name,arr[i].author,arr[i].price,arr[i].rating);
	}
}
void swap(book* a,book* b)
{
	book temp = *a;
    *a = *b;
    *b = temp;
}
void top_3_by_rating(book* arr,int size)
{
	int i,j,temp;

	for (i = 0; i < size; i++) 
	{
		for(j=i+1;j<size;j++)
		{
			if(arr[i].rating < arr[j].rating)
			{
				swap(&arr[i],&arr[j]);
			}
			
		}
      
    }
	printf("top1 is %s rating is %d \n",arr[0].name,arr[0].rating);
	printf("top2 is %s rating is %d \n",arr[1].name,arr[1].rating);
	printf("top3 is %s rating is %d \n",arr[2].name,arr[2].rating);
}
void top_3_by_price(book* arr,int size)
{
	int i,j,temp;

	for (i = 0; i < size; i++) 
	{
		for(j=i+1;j<size;j++)
		{
			if(arr[i].price < arr[j].price)
			{
				swap(&arr[i],&arr[j]);
			}
			
		}
      
    }
    printf("top1 is %s price is %lf \n",arr[0].name,arr[0].price);
	printf("top2 is %s price is %lf \n",arr[1].name,arr[1].price);
	printf("top3 is %s price is %lf \n",arr[2].name,arr[2].price);
}
void upload(book* arr,int size)
{
	if(size < 5)
	{
		struct book newbook;
		
		printf("Enter the bookinfo :");
		scanf("%d",&newbook.id);
		
		printf("Enter the name of book: ");
     	scanf("%s",&newbook.name);
	
	    printf("Enter the author:");
	    scanf("%s",&newbook.author);
	
	    printf("Enter the price : ");
	    scanf("%lf",&newbook.price);
	
	    printf("Enter the rating");
	    scanf("%d",&newbook.rating);
	   
	  arr[size]=newbook;
	  size++;
	  
	  printf("book add successfully \n");
	  displayinfo(arr,size);
	   
	}
	else
	{
		printf("max number of book reached \n");
	}
}


